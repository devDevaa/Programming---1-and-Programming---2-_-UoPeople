package PackageGenerics;

import java.util.Scanner;

public class GenericPairDemo {
public static void main(String args[])
{
	Pair<String> secretPair=new Pair<String>("Happy","Day");
	Scanner keyboard=new Scanner(System.in);
	String firstitem=keyboard.next();
	String seconditem=keyboard.next();
	Pair<String> inputPair=new Pair<String>(firstitem,seconditem);
	if(secretPair.equal(inputPair))
	{
		System.out.println("It is correct pair");
	}else
	{
		System.out.println("It is not correct pair");
	}
	System.out.println("Check Integer values");
	Pair<Integer> secretPair1=new Pair<Integer>(1,2);
	Integer firstint=keyboard.nextInt();
	Integer secondint=keyboard.nextInt();
	Pair<Integer> intpair1=new Pair<Integer>(firstint,secondint);
	if(secretPair1.equal(intpair1))
	{
		System.out.println("It is correct int");
	}
	else
	{
		System.out.println("It is not correct int");
	}
	
}
}
