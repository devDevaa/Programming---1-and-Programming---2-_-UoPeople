package CompareGenerics;

public class ComparableClass<T> implements Comparable{
	private T test;
public T getTest() {
		return test;
	}
	public void setTest(T test) {
		this.test = test;
	}
public ComparableClass(T string) {
		// TODO Auto-generated constructor stub
	this.test=string;
	}
public int compareTo(Object o) {
	return 0;
}
public static void main(String args[]){
	
	Sample<ComparableClass> sc=new 	Sample<ComparableClass>();
	sc.setData(new ComparableClass(null));
	ComparableClass c=sc.getData();
	if(c==null) System.out.println("Null");
	else  System.out.println("Not Null");
	Sample<ComparableClass> sc1=new Sample<ComparableClass>();
	ComparableClass ss=new ComparableClass("Test");
	
	sc1.setData(ss);
	System.out.println(ss.getTest());
	ComparableClass c1=sc1.getData();
		if(c1==null) System.out.println("Null");
	else  System.out.println(c1.getTest());

	///
		Sample<ComparableClass> sc2=new Sample<ComparableClass>();
		ComparableClass ss1=new ComparableClass(23);
		sc2.setData(ss1);
		System.out.println(ss1.getTest());
		ComparableClass css=sc2.getData();
			if(css==null) System.out.println("Null");
		else  System.out.println(css.getTest());

}

}